# Databricks notebook source
# MAGIC %md
# MAGIC ### Equipment with Most Failures  

# COMMAND ----------

import os
import logging
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from datetime import datetime

spark = SparkSession.builder.appName("EquipmentWithMostFailures").getOrCreate()
timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("EquipMostFailures")
logger.info(f"{timestamp} [INFO] Iniciando Transformação de dados: Equipment with Most Failures ") 

most_failures_equipment = spark.table("most_failures_equipment")
most_failures_equipment = most_failures_equipment.groupBy("equipment_name").count()
most_failures = most_failures_equipment.orderBy(col("count").desc()).limit(1)

logger.info(f"{timestamp} [INFO] Ação realizada com sucesso!")

# COMMAND ----------

# Extrair o nome do equipamento com o maior número de falhas (em lista)
most_failures_collect = most_failures.collect() 
if most_failures_collect:
    most_failures_row = most_failures_collect[0] 
    equipment_with_most_failures = most_failures_row["equipment_name"]
    logger.info(f"{timestamp} [INFO] Equipamento com maior número de falha: {equipment_with_most_failures}")
else:
    logger.info(f"{timestamp} [INFO] Nenhum dado encontrado para equipamentos com falhas.")

# COMMAND ----------

# Verifica se 'most_failures_collect' é uma lista e transforma em dataframe
if isinstance(most_failures_collect, list):
    most_failures_collect = spark.createDataFrame(most_failures_collect)

# Salvando a tabela no databricks.
logger.info(f"{timestamp} [INFO] Criando tabelas: 'most_failures_collect'...") 
most_failures_collect.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable("most_failures_collect")
display(most_failures)
logger.info(f"{timestamp} [INFO] Ação realizada com sucesso!")
logger.info(f"{timestamp} [INFO] Equipment with Most Failures - Finalizado com sucesso!") 

