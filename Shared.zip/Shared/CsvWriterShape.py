# Databricks notebook source
# Importar a sessão Spark
from pyspark.sql import SparkSession

logger.info(f"{timestamp} [INFO] Salvando Resultado em CSV: Inicializando...") 
logger.info(f"{timestamp} [INFO] Criando DataFrame...")
df1 = spark.table("most_failures_equipment")
df2 = spark.table("most_failures_collect")
df3 = spark.table("avg_failures_per_group")
logger.info(f"{timestamp} [INFO] Ação realizada com sucesso!")



# COMMAND ----------

# DBFS (Databricks File System) onde o arquivo CSV será salvo
output_path1 = f"dbfs:/FileStore/most_failures_equipment_{timestamp}.csv"
output_path2 = f"dbfs:/FileStore/most_failures_collect_{timestamp}.csv"
output_path3 = f"dbfs:/FileStore/avg_failures_per_group_{timestamp}.csv"
logger.info(f"{timestamp} [INFO] Salvado CSV: {output_path1}, {output_path2}, {output_path3}")

# COMMAND ----------

# Salvar o DataFrame como CSV
df1.write.csv(path=output_path1, mode="overwrite", header=True)
df2.write.csv(path=output_path2, mode="overwrite", header=True)
df3.write.csv(path=output_path3, mode="overwrite", header=True)
logger.info(f"{timestamp} [INFO] Ação realizada com sucesso!")

display(df1)
display(df2)
display(df3)

logger.info(f"{timestamp} [INFO] CSV Saving - Finalizado com sucesso!")
